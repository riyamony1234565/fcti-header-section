<!-- header_top section start -->
 <div class="header_top_section">
    <div class="header_top_row">
        <div class="header_logo" id="header_logo">
            <img src="img/brand_logo.png" alt="">
        </div>
        <div class="header_icon">
            <a href=""><i class="fa fa-facebook"></i></a>
            <a href=""><i class="fa fa-youtube"></i></a>
            <a href=""><i class="fa fa-instagram"></i></a>
            <a href=""><i class="fa fa-twitter"></i></a>
            <a href=""><i class="fa fa-linkedin"></i></a>
            <a id="phone" href="tel:01928248173">01928248173</a>
        </div>
    </div>
 </div>
<!-- header_top section end -->