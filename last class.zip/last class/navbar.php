
<div class="menu_section">
    <div class="menu_row">
        <div class="menu_logo">
            <img id="menu_logo" src="img/brand_logo.png" alt="">
        </div>
        <div class="menu_items">
            <ul>
                <li><a href="">হোম</a></li>
                <li  class="plus"><a href="">আমাদের সম্পর্কে</a></li>
                <li class="plus"><a href="">কোর্স ক্যাটাগরি </a></li>
                <li><a href="">সাফল্যের গল্প</a></li>
                <li  class="plus"><a href="">গ্যালারি</a></li>
                <li><a href="">ফ্রিল্যান্সিং</a></li>
                <li><a href="">যোগাযোগ</a></li>
                <li  class="plus"><a href="">ফলাফল</a></li>
                <li><a href="">লগইন</a></li>
            </ul>
        </div>
    </div>
 </div>



 <div class="div_manu">
 <iframe width="411" height="358" src="https://www.youtube.com/embed/IgwfjnHJAGc" title="how to data get php" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
 </div>
<!-- menu-section start -->